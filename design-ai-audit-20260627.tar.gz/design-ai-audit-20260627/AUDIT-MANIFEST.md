# Audit bundle manifest
- created: 2026-06-27T10:08:54Z
- git commit: 847cd19a
- branch: cursor/design-genome-ai-b8ae
- pipeline: v16.1-trend-intelligence-art-director

## Excluded on purpose
- .env, .env.local (secrets)
- node_modules, .next (build artifacts)
- deploy/ssh private keys
- public/generated, public/uploads, public/references (user data)
- data/design-memory.json (runtime learning store)

## Sanitized
- admin emails → admin@example.com
- VPS IP and production domain → placeholders
